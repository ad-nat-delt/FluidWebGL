# FluidWebGL

A cool satisfying webpage with fluid simulations on hover using WebGL and google analytics analytics.js

![image](https://user-images.githubusercontent.com/65241103/202865111-b358657d-aaaa-4e3b-b0ee-3a53eb1a39f2.png)
